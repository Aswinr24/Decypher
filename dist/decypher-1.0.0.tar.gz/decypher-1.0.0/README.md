### Speedy Cipher Decryption / Encryption tool
