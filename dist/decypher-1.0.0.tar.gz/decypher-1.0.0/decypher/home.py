from termcolor import colored
version= '1.0.0'
def screen():
    banner="""
    
    ███████████████████████████████████████████████
    █▄─▄▄▀█▄─▄▄─█─▄▄▄─█▄─█─▄█▄─▄▄─█─█─█▄─▄▄─█▄─▄▄▀█                      DECRYPT CIPHERS / ENCRYPT TEXT
    ██─██─██─▄█▀█─███▀██▄─▄███─▄▄▄█─▄─██─▄█▀██─▄─▄█                   https://github.com/Aswinr24/Decypher
    ▀▄▄▄▄▀▀▄▄▄▄▄▀▄▄▄▄▄▀▀▄▄▄▀▀▄▄▄▀▀▀▄▀▄▀▄▄▄▄▄▀▄▄▀▄▄▀                   ------------version 1.0.0----------- 
    
    """
    print(colored(banner,'yellow'))
    
    
    